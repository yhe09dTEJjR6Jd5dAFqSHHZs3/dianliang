import ctypes
import os
import subprocess
import sys
import threading
from ctypes import wintypes

if os.name != "nt":
    raise SystemExit("This program requires Windows.")

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)
user32 = ctypes.WinDLL("user32", use_last_error=True)

if not shell32.IsUserAnAdmin():
    params = subprocess.list2cmdline([os.path.abspath(__file__), *sys.argv[1:]])
    result = shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    if result <= 32:
        raise SystemExit("Administrator permission is required.")
    raise SystemExit

mutex = kernel32.CreateMutexW(None, False, "Local\\dianliang_py")
if not mutex:
    raise ctypes.WinError(ctypes.get_last_error())
if kernel32.GetLastError() == 183:
    raise SystemExit

powershell = os.path.join(os.environ["SystemRoot"], "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
CREATE_NO_WINDOW = 0x08000000

CALL = r'''
$ErrorActionPreference='Stop'
$inst=@(Get-CimInstance -Namespace root/wmi -ClassName MiCommonInterface -ErrorAction Stop)[0]
function M([byte]$op,[byte]$cmd,[byte]$arg,[byte]$val){
  $in=[byte[]]::new(32)
  $in[1]=$op;$in[3]=$cmd;$in[4]=$arg;$in[6]=$val
  [byte[]](Invoke-CimMethod -InputObject $inst -MethodName MiInterface -Arguments @{InData=$in} -ErrorAction Stop).OutData
}
'''

SELECT = CALL + r'''
$p=M 0xFA 0x08 0 0
if($p.Length -le 2 -or ($p[1] -ne 0x80 -and $p[1] -ne 0xE0)){throw 'unsupported'}
$choices=@(@(80,1),@(70,5),@(60,6),@(50,7),@(40,8))
foreach($c in $choices){
  $off=M 0xFB 0x10 0x02 0
  if($off.Length -le 1 -or $off[1] -ne 0x80){continue}
  $set=M 0xFB 0x10 0x02 ([byte]$c[1])
  if($set.Length -le 1 -or $set[1] -ne 0x80){continue}
  $get=M 0xFA 0x10 0x02 0
  if($get.Length -le 6 -or $get[1] -ne 0x80){continue}
  if($get[6] -eq $c[1] -or ($c[0] -eq 80 -and $get[6] -eq 4)){
    Write-Output ("{0},{1}" -f $c[0],$c[1])
    exit 0
  }
}
throw 'unsupported'
'''


def run_ps(script):
    return subprocess.run(
        [powershell, "-NoProfile", "-NonInteractive", "-Command", script],
        capture_output=True,
        text=True,
        creationflags=CREATE_NO_WINDOW,
    )


def select_limit():
    result = run_ps(SELECT)
    if result.returncode != 0:
        return None
    text = result.stdout.strip().splitlines()
    if not text:
        return None
    parts = text[-1].split(",")
    if len(parts) != 2:
        return None
    return int(parts[0]), int(parts[1])


def apply_limit(code):
    script = CALL + f'''
$off=M 0xFB 0x10 0x02 0
if($off.Length -le 1 -or $off[1] -ne 0x80){{throw 'off'}}
$set=M 0xFB 0x10 0x02 ([byte]{code})
if($set.Length -le 1 -or $set[1] -ne 0x80){{throw 'set'}}
$get=M 0xFA 0x10 0x02 0
if($get.Length -le 6 -or $get[1] -ne 0x80){{throw 'get'}}
if($get[6] -ne {code} -and -not ({code} -eq 1 -and $get[6] -eq 4)){{throw 'verify'}}
'''
    return run_ps(script).returncode == 0


state = select_limit()
if state is None:
    raise SystemExit("No verifiable firmware charge-limit interface was found; no battery setting was changed.")

percent, code = state
print(f"Battery charge protection active: {percent}%")

lock = threading.Lock()


def reapply():
    global percent, code
    if not lock.acquire(False):
        return
    try:
        if not apply_limit(code):
            new_state = select_limit()
            if new_state is not None:
                percent, code = new_state
    finally:
        lock.release()


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]


WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)


class WNDCLASSW(ctypes.Structure):
    _fields_ = [
        ("style", wintypes.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HCURSOR),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
    ]


WM_DESTROY = 0x0002
WM_POWERBROADCAST = 0x0218
PBT_APMSUSPEND = 0x0004
PBT_APMRESUMEAUTOMATIC = 0x0012
PBT_POWERSETTINGCHANGE = 0x8013
HWND_MESSAGE = wintypes.HWND(-3)
DEVICE_NOTIFY_WINDOW_HANDLE = 0x00000000
GUID_ACDC_POWER_SOURCE = GUID(
    0x5D3E9A59,
    0xE9D5,
    0x4B00,
    (ctypes.c_ubyte * 8)(0xA6, 0xBD, 0xFF, 0x34, 0xFF, 0x51, 0x65, 0x48),
)


@WNDPROC
def wndproc(hwnd, msg, wparam, lparam):
    if msg == WM_POWERBROADCAST and wparam in (PBT_APMSUSPEND, PBT_APMRESUMEAUTOMATIC, PBT_POWERSETTINGCHANGE):
        threading.Thread(target=reapply, daemon=True).start()
        return 1
    if msg == WM_DESTROY:
        user32.PostQuitMessage(0)
        return 0
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


hinstance = kernel32.GetModuleHandleW(None)
class_name = f"dianliang_{os.getpid()}"
wc = WNDCLASSW()
wc.lpfnWndProc = wndproc
wc.hInstance = hinstance
wc.lpszClassName = class_name
atom = user32.RegisterClassW(ctypes.byref(wc))
if not atom:
    raise ctypes.WinError(ctypes.get_last_error())

hwnd = user32.CreateWindowExW(0, class_name, class_name, 0, 0, 0, 0, 0, HWND_MESSAGE, None, hinstance, None)
if not hwnd:
    raise ctypes.WinError(ctypes.get_last_error())

notify = user32.RegisterPowerSettingNotification(hwnd, ctypes.byref(GUID_ACDC_POWER_SOURCE), DEVICE_NOTIFY_WINDOW_HANDLE)
if not notify:
    raise ctypes.WinError(ctypes.get_last_error())

msg = wintypes.MSG()
while True:
    result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
    if result == 0:
        break
    if result == -1:
        raise ctypes.WinError(ctypes.get_last_error())
    user32.TranslateMessage(ctypes.byref(msg))
    user32.DispatchMessageW(ctypes.byref(msg))
